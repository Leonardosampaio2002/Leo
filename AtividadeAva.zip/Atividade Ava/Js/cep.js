document.getElementById("cep").addEventListener("blur", () => {
    const cep = document.getElementById("cep").value.trim();
    const erro = document.getElementById("erroCep");
  
    if (cep.length !== 8 || isNaN(cep)) {
      erro.textContent = "CEP inválido!";
      return;
    }
  
    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then(response => response.json())
      .then(data => {
        if (data.erro) {
          erro.textContent = "CEP não encontrado!";
          limparCampos();
        } else {
          document.getElementById("rua").value = data.logradouro;
          document.getElementById("bairro").value = data.bairro;
          document.getElementById("cidade").value = data.localidade;
          document.getElementById("estado").value = data.uf;
          erro.textContent = "";
        }
      })
      .catch(() => {
        erro.textContent = "Erro ao buscar o CEP!";
      });
  });
  
  function limparCampos() {
    document.getElementById("rua").value = "";
    document.getElementById("bairro").value = "";
    document.getElementById("cidade").value = "";
    document.getElementById("estado").value = "";
  }
  