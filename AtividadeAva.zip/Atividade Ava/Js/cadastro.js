document.getElementById('formCadastro').addEventListener('submit', function (e) {
    e.preventDefault();
  
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const cpf = document.getElementById('cpf').value.trim();
    const idade = document.getElementById('idade').value.trim();
    const mensagem = document.getElementById('mensagem');
  
    if (!nome || !email || !cpf || !idade) {
      mensagem.textContent = "Todos os campos são obrigatórios!";
      mensagem.style.color = "blue";
      return;
    }
  
    const usuario = { nome, email, cpf, idade };
    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  
    usuarios.push(usuario);
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
  
    mensagem.textContent = "Usuário cadastrado com sucesso!";
    mensagem.style.color = "green";
  
    this.reset();
  });
  