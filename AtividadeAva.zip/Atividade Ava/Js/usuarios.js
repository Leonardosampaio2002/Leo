function carregarUsuarios() {
  const tabela = document.querySelector("#tabelaUsuarios tbody");
  tabela.innerHTML = "";
  const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

  usuarios.forEach((usuario, index) => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${usuario.nome}</td>
      <td>${usuario.email}</td>
      <td>${usuario.cpf}</td>
      <td>${usuario.idade}</td>
      <td>
        <button onclick="editarUsuario(${index})">✏️ Editar</button>
        <button onclick="excluirUsuario(${index})">❌ Excluir</button>
      </td>
    `;
    tabela.appendChild(tr);
  });
}

function excluirUsuario(index) {
  let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  usuarios.splice(index, 1);
  localStorage.setItem("usuarios", JSON.stringify(usuarios));
  carregarUsuarios();
}

function editarUsuario(index) {
  const novoNome = prompt("Novo nome:");
  const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  if (novoNome) {
    usuarios[index].nome = novoNome;
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
    carregarUsuarios();
  }
}

function limparTodos() {
  if (confirm("Deseja apagar todos os usuários?")) {
    localStorage.removeItem("usuarios");
    carregarUsuarios();
  }
}

document.addEventListener("DOMContentLoaded", carregarUsuarios);